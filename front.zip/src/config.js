// Configuración centralizada
export const API_URL = import.meta.env.VITE_API_URL || "http://localhost:8000";

console.log("🌍 Conectando a:", API_URL);

export const getApiUrl = (endpoint) => `${API_URL}${endpoint}`;
